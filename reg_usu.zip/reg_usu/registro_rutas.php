<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Registro rutas</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="blurBg-false" style="background-color:#EBEBEB">



<!-- Start Formoid form-->
<link rel="stylesheet" href="formoidr_files/formoid1/formoid-solid-blue.css" type="text/css" />
<script type="text/javascript" src="formoidr_files/formoid1/jquery.min.js"></script>
<form class="formoid-solid-blue" style="background-color:#FFFFFF;font-size:14px;font-family:'Roboto',Arial,Helvetica,sans-serif;color:#34495E;max-width:480px;min-width:150px" method="post" action="guardar_rutas.php"><div class="title"><h2>Registro rutas</h2></div>
	<div class="element-select" title="Persona a cargo"><label class="title"></label><div class="item-cont"><div class="large">
	<span>
	<?php
	echo"
	<div class='element-select'><label class='title'></label><div class='item-cont'><div class='large'><span>
	<select name='persona_cargo' required >
	<option value=''>Persona a cargo</option>";
	
	$sql="SELECT * FROM usuarios where estado=0";
$query=mysql_query($sql);


while ($valores = mysql_fetch_array($query)) {
	
	echo"
		
		<option value='".$valores['numero_documento']."'>".$valores['nombres']."</option>";
		
		}
		echo"</select><i></i><span class='icon-place'></span></span></div></div></div>";
		?>
		
		</select><i></i><span class="icon-place"></span></span></div></div></div>
<?php
	echo"
	<div class='element-select'><label class='title'></label><div class='item-cont'><div class='large'><span>
	<select name='origen' required >
	<option value=''>Seleccione origen</option>";
	
	$sql="SELECT DESCRIPCION FROM municipios";
$query=mysql_query($sql);


while ($valores = mysql_fetch_array($query)) {
	
	echo"
		
		<option value='".$valores['DESCRIPCION']."'>".$valores['DESCRIPCION']."</option>";
		
		}
		echo"</select><i></i><span class='icon-place'></span></span></div></div></div>";
		?>
	<?php
	echo"
	<div class='element-select'><label class='title'></label><div class='item-cont'><div class='large'><span>
	<select name='destino' required >
	<option value=''>Seleccione destino</option>";
	
	$sql="SELECT DESCRIPCION FROM municipios";
$query=mysql_query($sql);


while ($valores = mysql_fetch_array($query)) {
	
	echo"
		
		<option value='".$valores['DESCRIPCION']."'>".$valores['DESCRIPCION']."</option>";
		
		}
		echo"</select><i></i><span class='icon-place'></span></span></div></div></div>";
		?>
	<div class="element-number" title="Numero de kilometros a recorrer"><label class="title"></label><div class="item-cont"><input class="large" type="number" name="kilometros_recorrer" placeholder="Numero de kilometros a recorrer" required /><span class="icon-place"></span></div></div>
	<?php
	echo"
	<div class='element-select'><label class='title'></label><div class='item-cont'><div class='large'><span>
	<select name='vehiculo' required >
	<option value=''>Seleccione vehiculo</option>";
	
	$sql="SELECT * FROM vehiculos where documentacion_vigente='si' and estado=0";
$query=mysql_query($sql);


while ($valores = mysql_fetch_array($query)) {
	
	echo"
		
		<option value='".$valores['placa']."'>".$valores['marca'],$valores['modelo']."</option>";
		
		}
		echo"</select><i></i><span class='icon-place'></span></span></div></div></div>";
		?>
	<div class="element-checkbox" title="Materiales para llevar"><label class="title">Materiales para llevar</label>		
	<div class="column column1"><label>
	<input type="checkbox" name="materiales[]" value="Vigas de acero"/ ><span>Vigas de acero</span></label><label>
	<input type="checkbox" name="materiales[]" value="Arena"/ ><span>Arena</span></label><label>
	<input type="checkbox" name="materiales[]" value="Cemento"/ ><span>Cemento</span></label><label>
	<input type="checkbox" name="materiales[]" value="Ladrillo"/ ><span>Ladrillo</span></label>
	<label><input type="checkbox" name="todos" value="todos" class="cb-selector" data-for="materiales\["/ ><span>Todos</span></label>
	</div><span class="clearfix"></span>
</div>
	<div class="element-number" title="Numero total de kilos a llevar"><label class="title"></label><div class="item-cont"><input class="large" type="number"  name="numero_kilos" placeholder="Numero total de kilos a llevar" required /><span class="icon-place"></span></div></div>
<div class="submit"><input type="submit" value="Registrar" name="Registrar"/></div></form><p class="frmd"><a href="http://formoid.com/v29.php">bootstrap forms</a> Form</p><script type="text/javascript" src="formoidr_files/formoid1/formoid-solid-blue.js"></script>
<!-- Stop Formoid form-->
<script type='text/javascript'>
	!function($) {
		$('input[type=checkbox][class=cb-selector]').click(function() {
			var cb = $(this),
				name = cb.attr('data-for');
			
			if(name == null)
				return false;
			$('input[type=checkbox][name^='+name+']')
				.prop('checked', cb.prop('checked'))
				.click(function() {
					if(!$(this).prop('checked'))
						cb.prop('checked', false);
				});
		});
	}(jQuery);
</script>


</body>
</html>
