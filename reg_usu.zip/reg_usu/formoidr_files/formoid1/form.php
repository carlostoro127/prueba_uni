<?php

define('EMAIL_FOR_REPORTS', '');
define('RECAPTCHA_PRIVATE_KEY', '@privatekey@');
define('FINISH_URI', 'http://www.google.com');
define('FINISH_ACTION', 'redirect');
define('FINISH_MESSAGE', 'Thanks for filling out my form!');
define('UPLOAD_ALLOWED_FILE_TYPES', 'doc, docx, xls, csv, txt, rtf, html, zip, jpg, jpeg, png, gif');

define('_DIR_', str_replace('\\', '/', dirname(__FILE__)) . '/');
require_once _DIR_ . '/handler.php';

?>

<?php if (frmd_message()): ?>
<link rel="stylesheet" href="<?php echo dirname($form_path); ?>/formoid-solid-blue.css" type="text/css" />
<span class="alert alert-success"><?php echo FINISH_MESSAGE; ?></span>
<?php else: ?>
<!-- Start Formoid form-->
<link rel="stylesheet" href="<?php echo dirname($form_path); ?>/formoid-solid-blue.css" type="text/css" />
<script type="text/javascript" src="<?php echo dirname($form_path); ?>/jquery.min.js"></script>
<form class="formoid-solid-blue" style="background-color:#FFFFFF;font-size:14px;font-family:'Roboto',Arial,Helvetica,sans-serif;color:#34495E;max-width:480px;min-width:150px" method="post"><div class="title"><h2>Registro rutas</h2></div>
	<div class="element-select<?php frmd_add_class("select4"); ?>" title="Persona a cargo"><label class="title"></label><div class="item-cont"><div class="large"><span><select name="select4" >

		<option value="Persona a cargo">Persona a cargo</option>
		<option value="option 2">option 2</option>
		<option value="option 3">option 3</option></select><i></i><span class="icon-place"></span></span></div></div></div>
	<div class="element-select<?php frmd_add_class("select1"); ?>" title="Origen"><label class="title"></label><div class="item-cont"><div class="large"><span><select name="select1" >

		<option value="Origen">Origen</option>
		<option value="option 2">option 2</option>
		<option value="option 3">option 3</option></select><i></i><span class="icon-place"></span></span></div></div></div>
	<div class="element-select<?php frmd_add_class("select2"); ?>" title="Destino"><label class="title"></label><div class="item-cont"><div class="large"><span><select name="select2" >

		<option value="Destino">Destino</option>
		<option value="option 2">option 2</option>
		<option value="option 3">option 3</option></select><i></i><span class="icon-place"></span></span></div></div></div>
	<div class="element-number<?php frmd_add_class("number"); ?>" title="Numero de kilometros a recorrer"><label class="title"></label><div class="item-cont"><input class="large" type="text" min="0" max="100" name="number" placeholder="Numero de kilometros a recorrer" value=""/><span class="icon-place"></span></div></div>
	<div class="element-select<?php frmd_add_class("select3"); ?>" title="Selecccione vehiculo"><label class="title"></label><div class="item-cont"><div class="large"><span><select name="select3" >

		<option value="Selecccione vehiculo">Selecccione vehiculo</option>
		<option value="option 2">option 2</option>
		<option value="option 3">option 3</option></select><i></i><span class="icon-place"></span></span></div></div></div>
	<div class="element-checkbox<?php frmd_add_class("checkbox"); ?>" title="Materiales para llevar"><label class="title">Materiales para llevar</label>		<div class="column column1"><label><input type="checkbox" name="checkbox[]" value="Vigas de acero"/ ><span>Vigas de acero</span></label><label><input type="checkbox" name="checkbox[]" value="Arena"/ ><span>Arena</span></label><label><input type="checkbox" name="checkbox[]" value="Cemento"/ ><span>Cemento</span></label><label><input type="checkbox" name="checkbox[]" value="Ladrillo"/ ><span>Ladrillo</span></label></div><span class="clearfix"></span>
</div>
	<div class="element-number<?php frmd_add_class("number1"); ?>" title="Numero total de kilos a llevar"><label class="title"></label><div class="item-cont"><input class="large" type="text" min="0" max="100" name="number1" placeholder="Numero total de kilos a llevar" value=""/><span class="icon-place"></span></div></div>
<div class="submit"><input type="submit" value="Registrar"/></div></form><script type="text/javascript" src="<?php echo dirname($form_path); ?>/formoid-solid-blue.js"></script>

<!-- Stop Formoid form-->
<?php endif; ?>

<?php frmd_end_form(); ?>