<?php
include("conexion.php");

?>
<head>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
  <title>Cargando</title>
  
  <link rel="stylesheet" href="example/example.css">
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>

  <!-- This is what you need -->
  <script src="dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="dist/sweetalert.css">
  <!--.......................-->
  </head>
  <iframe src="sweetalert.html" style="display:none;"></iframe>


<?php
set_time_limit(0);
//error_reporting(0);
if(isset($_POST['Registrar'])&& !empty($_POST["Registrar"]))
    {
		
			
$nombres=$_POST['nombres'];
$tipo_documento=$_POST['tipo_documento']; 
$numero_documento=$_POST['numero_documento']; 
$numero_lic_conduccion=$_POST['numero_lic_conduccion']; 	
$estado=0;
       //guardamos en base de datos la línea leida

	  $sql="INSERT INTO usuarios(nombres, apellidos, tipo_documento, numero_documento, numero_lic_conduccion,estado)
	  VALUES ('".$nombres."', '".$tipo_documento."', '".$numero_documento."', '".$numero_lic_conduccion."','".$estado."')";
	   // arreglo acentos 
$qry_code = utf8_decode($sql);
  
  $result = mysql_query($qry_code) or die(mysql_error());
  
  
echo "

<script>

swal({
  title: 'Realizado',
  text: 'Datos registrados exitosamente',
  type: 'success',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Continuar',
  closeOnConfirm: true
},
function(){
  window.location='registro_usuarios.php';
});



</script>";
	}
	else
	{
            //si aparece esto es posible que el dato no tenga el formato adecuado
             echo "

<script>

swal({
  title: 'Error',
  text: 'El registro no pudo ser cargado',
  type: 'error',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Volver atras',
  closeOnConfirm: true
},
function(){
  window.location='registro_usuarios.php';
});



</script>";
	}
	?>
	
