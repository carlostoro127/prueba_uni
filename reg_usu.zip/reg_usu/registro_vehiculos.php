<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Registro vehiculos</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="blurBg-false" style="background-color:#EBEBEB">



<!-- Start Formoid form-->
<link rel="stylesheet" href="formoidv_files/formoid1/formoid-solid-blue.css" type="text/css" />
<script type="text/javascript" src="formoidv_files/formoid1/jquery.min.js"></script>
<form class="formoid-solid-blue" style="background-color:#FFFFFF;font-size:14px;font-family:'Roboto',Arial,Helvetica,sans-serif;color:#34495E;max-width:480px;min-width:150px" method="post" action="guardar_vehiculos.php"><div class="title"><h2>Registro vehiculos</h2></div>
	<div class="element-input" title="Marca"><label class="title"></label><div class="item-cont"><input class="large" type="text" name="marca" placeholder="Marca" required /><span class="icon-place"></span></div></div>
	<div class="element-input" title="Modelo"><label class="title"></label><div class="item-cont"><input class="large" type="text" name="modelo" placeholder="Modelo" required /><span class="icon-place"></span></div></div>
	<div class="element-input" title="Placa"><label class="title"></label><div class="item-cont"><input class="large" type="text" name="placa" placeholder="Placa" required /><span class="icon-place"></span></div></div>
	<div class="element-select" title="Documentacion vigente"><label class="title"></label><div class="item-cont"><div class="large"><span>
	<select name="documentacion_vigente" required>

		<option value="">Documentacion vigente</option>
		<option value="Si">Si</option>
		<option value="No">No</option></select><i></i><span class="icon-place"></span></span></div></div></div>
<div class="submit"><input type="submit" value="Registrar" name="Registrar" /></div></form>
<!-- Stop Formoid form-->



</body>
</html>
